import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { FeaturedTurfs } from '@/components/FeaturedTurfs';
import { CitySelector } from '@/components/CitySelector';
import { WhyChooseUs } from '@/components/WhyChooseUs';
import { Footer } from '@/components/Footer';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <Hero />
      <FeaturedTurfs />
      <CitySelector />
      <WhyChooseUs />
      <Footer />
    </div>
  );
};

export default Index;
