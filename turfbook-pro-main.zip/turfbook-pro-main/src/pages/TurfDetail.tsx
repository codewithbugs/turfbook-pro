import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { turfs, generateTimeSlots, calculateDiscount } from '@/lib/data';
import { TimeSlot } from '@/lib/types';
import { Star, MapPin, Clock, Zap, ChevronLeft, ChevronRight, Check, Percent } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

const TurfDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const turf = turfs.find((t) => t.id === id);

  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedSport, setSelectedSport] = useState<'cricket' | 'football'>(
    turf?.sports[0] || 'football'
  );
  const [selectedSlots, setSelectedSlots] = useState<string[]>([]);

  const timeSlots = useMemo(() => {
    if (!turf) return [];
    return generateTimeSlots(selectedDate, turf.pricePerHour);
  }, [selectedDate, turf]);

  if (!turf) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-display text-2xl font-bold text-foreground mb-4">Turf not found</h1>
          <Button onClick={() => navigate('/turfs')}>Browse Turfs</Button>
        </div>
      </div>
    );
  }

  const toggleSlot = (slotId: string) => {
    setSelectedSlots((prev) =>
      prev.includes(slotId)
        ? prev.filter((s) => s !== slotId)
        : [...prev, slotId]
    );
  };

  const discount = calculateDiscount(selectedSlots.length);
  const subtotal = selectedSlots.length * turf.pricePerHour;
  const discountAmount = subtotal * discount;
  const total = subtotal - discountAmount;

  const handleBooking = () => {
    if (selectedSlots.length === 0) {
      toast({
        title: "No slots selected",
        description: "Please select at least one time slot to proceed.",
        variant: "destructive",
      });
      return;
    }
    navigate('/checkout', {
      state: {
        turfId: turf.id,
        turfName: turf.name,
        turfAddress: turf.address,
        date: selectedDate.toISOString().split('T')[0],
        slots: selectedSlots,
        sport: selectedSport,
        pricePerHour: turf.pricePerHour,
        subtotal,
        discount,
        discountAmount,
        total,
      }
    });
  };

  // Date navigation
  const dates = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() + i);
    return date;
  });

  const formatDate = (date: Date) => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return {
      day: days[date.getDay()],
      date: date.getDate(),
      month: date.toLocaleString('default', { month: 'short' }),
    };
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Back Button */}
          <Button
            variant="ghost"
            className="mb-6 gap-2"
            onClick={() => navigate('/turfs')}
          >
            <ChevronLeft className="w-4 h-4" />
            Back to Turfs
          </Button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Turf Info */}
            <div className="lg:col-span-2">
              {/* Hero Image */}
              <div className="relative h-64 md:h-96 rounded-2xl overflow-hidden mb-6">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-accent/20" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-24 h-24 rounded-full bg-primary/20 flex items-center justify-center">
                    <Zap className="w-12 h-12 text-primary" />
                  </div>
                </div>
                <div className="absolute top-4 right-4 flex gap-2">
                  {turf.sports.map((sport) => (
                    <Badge key={sport} variant="sport" className="capitalize">
                      {sport}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Info */}
              <div className="mb-8">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-2">
                      {turf.name}
                    </h1>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      <span>{turf.address}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 bg-secondary rounded-full px-3 py-1">
                    <Star className="w-5 h-5 text-accent fill-accent" />
                    <span className="font-semibold text-foreground">{turf.rating}</span>
                    <span className="text-sm text-muted-foreground">({turf.reviewCount})</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 mb-6">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">{turf.openTime} - {turf.closeTime}</span>
                </div>

                {/* Amenities */}
                <div className="mb-6">
                  <h3 className="font-display font-semibold text-foreground mb-3">Amenities</h3>
                  <div className="flex flex-wrap gap-2">
                    {turf.amenities.map((amenity) => (
                      <span
                        key={amenity}
                        className="px-3 py-1.5 rounded-lg bg-secondary text-secondary-foreground text-sm"
                      >
                        {amenity}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Multi-hour discount info */}
                <Card className="bg-primary/5 border-primary/20">
                  <CardContent className="p-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                      <Percent className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">Multi-Hour Discount</p>
                      <p className="text-sm text-muted-foreground">
                        Book 2 hrs: 10% off • 3 hrs: 15% off • 4+ hrs: 20% off
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Date Selection */}
              <div className="mb-6">
                <h3 className="font-display font-semibold text-foreground mb-4">Select Date</h3>
                <div className="flex gap-2 overflow-x-auto pb-2">
                  {dates.map((date) => {
                    const formatted = formatDate(date);
                    const isSelected = date.toDateString() === selectedDate.toDateString();
                    const isToday = date.toDateString() === new Date().toDateString();
                    return (
                      <button
                        key={date.toISOString()}
                        onClick={() => setSelectedDate(date)}
                        className={cn(
                          "flex-shrink-0 w-16 py-3 rounded-xl border transition-all duration-200 text-center",
                          isSelected
                            ? "bg-primary border-primary text-primary-foreground"
                            : "bg-secondary border-border hover:border-primary/50"
                        )}
                      >
                        <p className="text-xs font-medium">{formatted.day}</p>
                        <p className="text-lg font-bold">{formatted.date}</p>
                        <p className="text-xs">{isToday ? 'Today' : formatted.month}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Sport Selection */}
              {turf.sports.length > 1 && (
                <div className="mb-6">
                  <h3 className="font-display font-semibold text-foreground mb-4">Select Sport</h3>
                  <div className="flex gap-3">
                    {turf.sports.map((sport) => (
                      <button
                        key={sport}
                        onClick={() => setSelectedSport(sport)}
                        className={cn(
                          "px-6 py-3 rounded-xl border font-medium capitalize transition-all duration-200",
                          selectedSport === sport
                            ? "bg-primary border-primary text-primary-foreground"
                            : "bg-secondary border-border hover:border-primary/50"
                        )}
                      >
                        {sport}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Time Slots */}
              <div>
                <h3 className="font-display font-semibold text-foreground mb-4">Select Time Slots</h3>
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
                  {timeSlots.map((slot) => {
                    const isSelected = selectedSlots.includes(slot.id);
                    return (
                      <button
                        key={slot.id}
                        onClick={() => slot.available && toggleSlot(slot.id)}
                        disabled={!slot.available}
                        className={cn(
                          "relative py-3 px-2 rounded-xl border text-center transition-all duration-200",
                          !slot.available && "opacity-40 cursor-not-allowed bg-muted",
                          slot.available && !isSelected && "bg-secondary border-border hover:border-primary/50",
                          isSelected && "bg-primary border-primary text-primary-foreground"
                        )}
                      >
                        <p className="font-semibold">{slot.time}</p>
                        <p className="text-xs mt-1">₹{slot.price.toLocaleString()}</p>
                        {isSelected && (
                          <div className="absolute -top-1 -right-1 w-5 h-5 bg-accent rounded-full flex items-center justify-center">
                            <Check className="w-3 h-3 text-accent-foreground" />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Booking Summary */}
            <div className="lg:col-span-1">
              <Card variant="elevated" className="sticky top-24">
                <CardContent className="p-6">
                  <h3 className="font-display font-semibold text-xl text-foreground mb-4">
                    Booking Summary
                  </h3>

                  <div className="space-y-3 mb-6">
                    <div className="flex justify-between text-muted-foreground">
                      <span>Date</span>
                      <span className="text-foreground font-medium">
                        {selectedDate.toLocaleDateString('en-IN', {
                          weekday: 'short',
                          day: 'numeric',
                          month: 'short',
                        })}
                      </span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>Sport</span>
                      <span className="text-foreground font-medium capitalize">{selectedSport}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>Duration</span>
                      <span className="text-foreground font-medium">{selectedSlots.length} hour(s)</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>Price per hour</span>
                      <span className="text-foreground font-medium">₹{turf.pricePerHour.toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="border-t border-border pt-4 space-y-2 mb-6">
                    <div className="flex justify-between text-muted-foreground">
                      <span>Subtotal</span>
                      <span>₹{subtotal.toLocaleString()}</span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between text-primary">
                        <span>Discount ({(discount * 100).toFixed(0)}%)</span>
                        <span>-₹{discountAmount.toLocaleString()}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-xl font-bold text-foreground pt-2">
                      <span>Total</span>
                      <span>₹{total.toLocaleString()}</span>
                    </div>
                  </div>

                  <Button
                    variant="hero"
                    size="xl"
                    className="w-full"
                    onClick={handleBooking}
                  >
                    Proceed to Book
                  </Button>

                  <p className="text-xs text-muted-foreground text-center mt-4">
                    Free cancellation up to 24 hours before
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default TurfDetail;
