import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { TurfCard } from '@/components/TurfCard';
import { Button } from '@/components/ui/button';
import { turfs, cities } from '@/lib/data';
import { Filter, MapPin, Trophy, X } from 'lucide-react';

const TurfsPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [showFilters, setShowFilters] = useState(false);
  
  const selectedCity = searchParams.get('city') || '';
  const selectedSport = searchParams.get('sport') || '';

  const filteredTurfs = useMemo(() => {
    return turfs.filter((turf) => {
      const cityMatch = !selectedCity || turf.city === selectedCity;
      const sportMatch = !selectedSport || turf.sports.includes(selectedSport as 'cricket' | 'football');
      return cityMatch && sportMatch;
    });
  }, [selectedCity, selectedSport]);

  const updateFilter = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams);
    if (value) {
      params.set(key, value);
    } else {
      params.delete(key);
    }
    setSearchParams(params);
  };

  const clearFilters = () => {
    setSearchParams({});
  };

  const hasFilters = selectedCity || selectedSport;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="mb-8">
            <h1 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Browse <span className="text-gradient">Turfs</span>
            </h1>
            <p className="text-lg text-muted-foreground">
              {filteredTurfs.length} turfs available {selectedCity && `in ${selectedCity}`}
            </p>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-4 mb-8">
            <div className="flex-1 flex flex-wrap gap-3">
              {/* City Filter */}
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <select
                  value={selectedCity}
                  onChange={(e) => updateFilter('city', e.target.value)}
                  className="h-10 pl-10 pr-8 rounded-lg bg-secondary border border-border text-foreground text-sm appearance-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="">All Cities</option>
                  {cities.map((city) => (
                    <option key={city.id} value={city.name}>{city.name}</option>
                  ))}
                </select>
              </div>

              {/* Sport Filter */}
              <div className="relative">
                <Trophy className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <select
                  value={selectedSport}
                  onChange={(e) => updateFilter('sport', e.target.value)}
                  className="h-10 pl-10 pr-8 rounded-lg bg-secondary border border-border text-foreground text-sm appearance-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="">All Sports</option>
                  <option value="cricket">Cricket</option>
                  <option value="football">Football</option>
                </select>
              </div>

              {hasFilters && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearFilters}
                  className="gap-1 text-muted-foreground"
                >
                  <X className="w-4 h-4" />
                  Clear Filters
                </Button>
              )}
            </div>
          </div>

          {/* Turfs Grid */}
          {filteredTurfs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredTurfs.map((turf, index) => (
                <div
                  key={turf.id}
                  className="animate-slide-up"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <TurfCard turf={turf} />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <div className="w-20 h-20 rounded-full bg-secondary flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-10 h-10 text-muted-foreground" />
              </div>
              <h3 className="font-display text-xl font-semibold text-foreground mb-2">
                No turfs found
              </h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your filters to find more turfs
              </p>
              <Button variant="outline" onClick={clearFilters}>
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default TurfsPage;
